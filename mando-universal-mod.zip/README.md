# Mando Universal (Forge 1.20.1)

Mod **solo de cliente** para jugar a Minecraft con mando: PS4, PS5, Xbox 360/One/Series,
Switch Pro y cualquier mando que Windows/Linux/Mac detecte (cable, Bluetooth o receptor USB).
No hace falta instalarlo en el servidor.

## Como compilarlo con GitHub
1. Sube **todo el contenido** de este zip a la raiz de tu repositorio (con la carpeta `.github`).
2. En la pestana **Actions** se compila solo (o pulsa "Run workflow").
3. Descarga el artefacto `mando-universal-jar` y mete el `.jar` en `mods/`.

## Controles
**En partida**
| Mando | Accion |
|---|---|
| Stick izquierdo | Moverse |
| Stick derecho | Camara |
| A | Saltar |
| B (mantener) | Agacharse |
| RT | Atacar / romper |
| LT | Usar / colocar |
| LB / RB | Hotbar anterior / siguiente |
| X | Cambiar item de mano |
| Y | Inventario |
| L3 (clic stick izq.) | Correr (alternar) |
| Cruceta arriba | Cambiar camara (F5) |
| Cruceta abajo | Tirar item |
| Cruceta izquierda | Logros |
| Cruceta derecha | Copiar bloque (clic central) |
| Start | Menu de pausa |
| Back / Select (mantener) | Lista de jugadores |

**En menus e inventarios**
| Mando | Accion |
|---|---|
| Stick izquierdo | Mover el cursor |
| A | Clic izquierdo (mantener para arrastrar) |
| X | Clic derecho |
| Y | Shift+clic (mover item rapido) |
| B | Cerrar / volver |
| Stick derecho o cruceta arriba/abajo | Scroll |
| LB / RB | Cambiar hotbar |
| Cruceta izquierda | Intercambiar item con la ranura de hotbar elegida |
| R3 / L3 | Tirar 1 / tirar pila entera |

Escribir (chat, yunque, carteles) sigue necesitando teclado.

## Configuracion
`config/mandouniversal-client.toml`: zona muerta (drift), velocidad de camara, invertir eje Y,
sensibilidad de gatillos, mando concreto si tienes varios, correr automatico.

## Si tu mando no se reconoce
Descarga `gamecontrollerdb.txt` de https://github.com/mdqinc/SDL_GameControllerDB y ponlo en
`config/mandouniversal/`. Si aun asi no tiene perfil, el mod usa un modo generico y puedes ajustar
los indices de ejes en la seccion `genericMode` del config.
