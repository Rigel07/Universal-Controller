package com.mandouniversal;

/** Botones del mando. El orden coincide con los indices de GLFW_GAMEPAD_BUTTON_*. */
public enum Btn {
    A, B, X, Y, LB, RB, BACK, START, GUIDE, L3, R3,
    DPAD_UP, DPAD_RIGHT, DPAD_DOWN, DPAD_LEFT
}
