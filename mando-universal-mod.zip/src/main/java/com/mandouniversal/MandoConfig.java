package com.mandouniversal;

import net.minecraftforge.common.ForgeConfigSpec;

public final class MandoConfig {
    public static final ForgeConfigSpec SPEC;

    public static final ForgeConfigSpec.BooleanValue ENABLED;
    public static final ForgeConfigSpec.IntValue CONTROLLER_INDEX;
    public static final ForgeConfigSpec.BooleanValue ALLOW_GENERIC;
    public static final ForgeConfigSpec.DoubleValue DEADZONE;
    public static final ForgeConfigSpec.DoubleValue LOOK_SPEED_X;
    public static final ForgeConfigSpec.DoubleValue LOOK_SPEED_Y;
    public static final ForgeConfigSpec.BooleanValue INVERT_Y;
    public static final ForgeConfigSpec.DoubleValue TRIGGER_THRESHOLD;
    public static final ForgeConfigSpec.DoubleValue CURSOR_SPEED;
    public static final ForgeConfigSpec.BooleanValue AUTO_SPRINT;

    public static final ForgeConfigSpec.IntValue RAW_LEFT_X;
    public static final ForgeConfigSpec.IntValue RAW_LEFT_Y;
    public static final ForgeConfigSpec.IntValue RAW_RIGHT_X;
    public static final ForgeConfigSpec.IntValue RAW_RIGHT_Y;
    public static final ForgeConfigSpec.IntValue RAW_LEFT_TRIGGER;
    public static final ForgeConfigSpec.IntValue RAW_RIGHT_TRIGGER;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();

        b.push("general");
        ENABLED = b.comment("Activa el soporte de mando.")
                .define("enabled", true);
        CONTROLLER_INDEX = b.comment("-1 = automatico (primer mando que encuentre). 0-15 = usar ese mando concreto si tienes varios.")
                .defineInRange("controllerIndex", -1, -1, 15);
        ALLOW_GENERIC = b.comment("Si un mando no tiene perfil conocido, usar modo generico (ejes y botones en crudo).")
                .define("allowGenericMode", true);
        b.pop();

        b.push("sticks");
        DEADZONE = b.comment("Zona muerta de los sticks (arregla el 'drift').")
                .defineInRange("deadzone", 0.18D, 0.02D, 0.6D);
        LOOK_SPEED_X = b.comment("Velocidad de giro horizontal con el stick derecho.")
                .defineInRange("lookSpeedX", 1100.0D, 100.0D, 4000.0D);
        LOOK_SPEED_Y = b.comment("Velocidad de giro vertical con el stick derecho.")
                .defineInRange("lookSpeedY", 800.0D, 100.0D, 4000.0D);
        INVERT_Y = b.comment("Invertir el eje vertical de la camara.")
                .define("invertY", false);
        TRIGGER_THRESHOLD = b.comment("Cuanto hay que apretar los gatillos (LT/RT) para que cuenten como pulsados.")
                .defineInRange("triggerThreshold", 0.35D, 0.05D, 0.95D);
        CURSOR_SPEED = b.comment("Velocidad del cursor en menus e inventarios (pixeles por segundo).")
                .defineInRange("cursorSpeed", 1300.0D, 200.0D, 5000.0D);
        AUTO_SPRINT = b.comment("Correr automaticamente al empujar el stick izquierdo a tope hacia delante.")
                .define("autoSprint", false);
        b.pop();

        b.comment("Solo para el modo generico (mandos sin perfil). Indices de ejes en crudo.").push("genericMode");
        RAW_LEFT_X = b.defineInRange("leftStickX", 0, 0, 31);
        RAW_LEFT_Y = b.defineInRange("leftStickY", 1, 0, 31);
        RAW_RIGHT_X = b.defineInRange("rightStickX", 2, 0, 31);
        RAW_RIGHT_Y = b.defineInRange("rightStickY", 3, 0, 31);
        RAW_LEFT_TRIGGER = b.defineInRange("leftTrigger", 4, -1, 31);
        RAW_RIGHT_TRIGGER = b.defineInRange("rightTrigger", 5, -1, 31);
        b.pop();

        SPEC = b.build();
    }

    private MandoConfig() {}
}
