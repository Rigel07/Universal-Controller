package com.mandouniversal;

import net.minecraftforge.fml.loading.FMLPaths;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWGamepadState;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;

/** Lee el estado del mando (cualquier mando que GLFW detecte) y calcula pulsaciones. */
public final class ControllerInput {
    private static final int N = Btn.values().length;
    /** Indices de botones en crudo (modo generico) para A,B,X,Y,LB,RB,BACK,START,GUIDE,L3,R3. */
    private static final int[] RAW_BTN = {0, 1, 2, 3, 4, 5, 6, 7, -1, 8, 9};
    private static boolean mappingsLoaded;

    private final boolean[] down = new boolean[N];
    private final boolean[] prev = new boolean[N];

    public float lx, ly, rx, ry, lt, rt;
    public int jid = -1;
    public boolean mapped;
    public String name = "";
    public boolean justConnected, justDisconnected;

    private long nextScan;
    private boolean ltCal, rtCal;

    public boolean connected() { return jid >= 0; }
    public boolean held(Btn b) { return down[b.ordinal()]; }
    public boolean pressed(Btn b) { return down[b.ordinal()] && !prev[b.ordinal()]; }
    public boolean released(Btn b) { return !down[b.ordinal()] && prev[b.ordinal()]; }

    /** Se llama una vez por frame. */
    public void poll() {
        loadMappingsOnce();
        System.arraycopy(down, 0, prev, 0, N);

        if (!MandoConfig.ENABLED.get()) {
            if (jid >= 0) disconnect();
            clearState();
            return;
        }

        if (jid >= 0 && !GLFW.glfwJoystickPresent(jid)) {
            disconnect();
        }

        if (jid < 0) {
            long now = System.nanoTime();
            if (now >= nextScan) {
                nextScan = now + 1_000_000_000L;
                scan();
            }
            if (jid < 0) {
                clearState();
                return;
            }
        }

        if (mapped) readMapped(); else readGeneric();
    }

    private void scan() {
        int preferred = MandoConfig.CONTROLLER_INDEX.get();
        int firstGeneric = -1;
        for (int i = GLFW.GLFW_JOYSTICK_1; i <= GLFW.GLFW_JOYSTICK_LAST; i++) {
            if (preferred >= 0 && i != preferred) continue;
            if (!GLFW.glfwJoystickPresent(i)) continue;
            if (GLFW.glfwJoystickIsGamepad(i)) {
                connect(i, true);
                return;
            }
            if (firstGeneric < 0 && MandoConfig.ALLOW_GENERIC.get() && looksLikeController(i)) {
                firstGeneric = i;
            }
        }
        if (firstGeneric >= 0) connect(firstGeneric, false);
    }

    private static boolean looksLikeController(int id) {
        FloatBuffer axes = GLFW.glfwGetJoystickAxes(id);
        ByteBuffer btn = GLFW.glfwGetJoystickButtons(id);
        return axes != null && btn != null && axes.limit() >= 4 && btn.limit() >= 6;
    }

    private void connect(int id, boolean isMapped) {
        jid = id;
        mapped = isMapped;
        String n = isMapped ? GLFW.glfwGetGamepadName(id) : GLFW.glfwGetJoystickName(id);
        name = n == null ? "Mando " + (id + 1) : n;
        ltCal = false;
        rtCal = false;
        justConnected = true;
        MandoUniversalMod.LOGGER.info("[MandoUniversal] Mando conectado: {} (slot {}, perfil conocido: {})", name, id, isMapped);
    }

    private void disconnect() {
        MandoUniversalMod.LOGGER.info("[MandoUniversal] Mando desconectado: {}", name);
        jid = -1;
        justDisconnected = true;
        clearState();
    }

    private void clearState() {
        Arrays.fill(down, false);
        lx = ly = rx = ry = lt = rt = 0f;
    }

    private void readMapped() {
        try (MemoryStack stack = MemoryStack.stackPush()) {
            GLFWGamepadState s = GLFWGamepadState.malloc(stack);
            if (!GLFW.glfwGetGamepadState(jid, s)) {
                clearState();
                return;
            }
            lx = s.axes(GLFW.GLFW_GAMEPAD_AXIS_LEFT_X);
            ly = s.axes(GLFW.GLFW_GAMEPAD_AXIS_LEFT_Y);
            rx = s.axes(GLFW.GLFW_GAMEPAD_AXIS_RIGHT_X);
            ry = s.axes(GLFW.GLFW_GAMEPAD_AXIS_RIGHT_Y);
            lt = trigger(s.axes(GLFW.GLFW_GAMEPAD_AXIS_LEFT_TRIGGER), true);
            rt = trigger(s.axes(GLFW.GLFW_GAMEPAD_AXIS_RIGHT_TRIGGER), false);
            for (int i = 0; i < N; i++) {
                down[i] = s.buttons(i) != 0;
            }
        }
    }

    private void readGeneric() {
        FloatBuffer axes = GLFW.glfwGetJoystickAxes(jid);
        ByteBuffer btn = GLFW.glfwGetJoystickButtons(jid);
        ByteBuffer hats = GLFW.glfwGetJoystickHats(jid);
        if (axes == null || btn == null) {
            clearState();
            return;
        }
        lx = axis(axes, MandoConfig.RAW_LEFT_X.get());
        ly = axis(axes, MandoConfig.RAW_LEFT_Y.get());
        rx = axis(axes, MandoConfig.RAW_RIGHT_X.get());
        ry = axis(axes, MandoConfig.RAW_RIGHT_Y.get());
        lt = trigger(axis(axes, MandoConfig.RAW_LEFT_TRIGGER.get()), true);
        rt = trigger(axis(axes, MandoConfig.RAW_RIGHT_TRIGGER.get()), false);

        Arrays.fill(down, false);
        for (int i = 0; i < RAW_BTN.length; i++) {
            int idx = RAW_BTN[i];
            down[i] = idx >= 0 && idx < btn.limit() && btn.get(idx) != 0;
        }
        int hat = (hats != null && hats.limit() > 0) ? hats.get(0) : 0;
        down[Btn.DPAD_UP.ordinal()] = (hat & GLFW.GLFW_HAT_UP) != 0;
        down[Btn.DPAD_RIGHT.ordinal()] = (hat & GLFW.GLFW_HAT_RIGHT) != 0;
        down[Btn.DPAD_DOWN.ordinal()] = (hat & GLFW.GLFW_HAT_DOWN) != 0;
        down[Btn.DPAD_LEFT.ordinal()] = (hat & GLFW.GLFW_HAT_LEFT) != 0;
    }

    private static float axis(FloatBuffer b, int idx) {
        return idx >= 0 && idx < b.limit() ? b.get(idx) : 0f;
    }

    /**
     * Convierte el eje de un gatillo (-1 reposo ... 1 a fondo) a 0..1.
     * Algunos mandos reportan 0 hasta que se toca el gatillo: hasta ver el valor de reposo (-1)
     * solo se cuenta si esta claramente apretado, asi no se queda "pulsado" solo.
     */
    private float trigger(float raw, boolean left) {
        boolean cal = left ? ltCal : rtCal;
        if (raw <= -0.9f) {
            cal = true;
            if (left) ltCal = true; else rtCal = true;
        }
        if (!cal && raw < 0.6f) return 0f;
        float v = (raw + 1f) * 0.5f;
        return v < 0f ? 0f : Math.min(v, 1f);
    }

    /** Carga mappings extra (SDL_GameControllerDB) para que mandos raros se reconozcan. */
    private static void loadMappingsOnce() {
        if (mappingsLoaded) return;
        mappingsLoaded = true;
        try {
            Path dir = FMLPaths.CONFIGDIR.get().resolve("mandouniversal");
            Files.createDirectories(dir);
            Path db = dir.resolve("gamecontrollerdb.txt");
            if (Files.isRegularFile(db)) {
                String text = Files.readString(db);
                ByteBuffer buf = MemoryUtil.memUTF8(text);
                try {
                    boolean ok = GLFW.glfwUpdateGamepadMappings(buf);
                    MandoUniversalMod.LOGGER.info("[MandoUniversal] gamecontrollerdb.txt cargado: {}", ok);
                } finally {
                    MemoryUtil.memFree(buf);
                }
            } else {
                Path readme = dir.resolve("LEEME.txt");
                if (!Files.exists(readme)) {
                    Files.writeString(readme,
                            "Si tu mando no se reconoce bien, descarga gamecontrollerdb.txt de\n"
                            + "https://github.com/mdqinc/SDL_GameControllerDB y ponlo en esta carpeta.\n"
                            + "Reinicia Minecraft y el mod lo cargara automaticamente.\n");
                }
            }
        } catch (IOException | RuntimeException e) {
            MandoUniversalMod.LOGGER.warn("[MandoUniversal] No se pudo cargar gamecontrollerdb.txt", e);
        }
    }
}
