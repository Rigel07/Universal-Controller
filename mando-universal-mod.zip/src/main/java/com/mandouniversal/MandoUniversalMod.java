package com.mandouniversal;

import com.mojang.logging.LogUtils;
import net.minecraftforge.fml.IExtensionPoint;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import org.slf4j.Logger;

@Mod(MandoUniversalMod.MODID)
public class MandoUniversalMod {
    public static final String MODID = "mandouniversal";
    public static final Logger LOGGER = LogUtils.getLogger();

    public MandoUniversalMod() {
        ModLoadingContext ctx = ModLoadingContext.get();
        // Mod solo de cliente: se puede entrar a cualquier servidor sin que el servidor lo tenga.
        ctx.registerExtensionPoint(IExtensionPoint.DisplayTest.class,
                () -> new IExtensionPoint.DisplayTest(() -> IExtensionPoint.DisplayTest.IGNORESERVERONLY, (remote, isServer) -> true));
        ctx.registerConfig(ModConfig.Type.CLIENT, MandoConfig.SPEC);
    }
}
