package com.mandouniversal;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen;
import net.minecraft.client.player.Input;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.Slot;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.MovementInputUpdateEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWCursorPosCallback;
import org.lwjgl.glfw.GLFWMouseButtonCallback;
import org.lwjgl.glfw.GLFWScrollCallback;

@Mod.EventBusSubscriber(modid = MandoUniversalMod.MODID, value = Dist.CLIENT)
public final class ControllerHandler {
    private static final ControllerInput PAD = new ControllerInput();
    private static final boolean[] SUPPRESSED = new boolean[Btn.values().length];
    private static final boolean[] CLICK_HELD = new boolean[2]; // 0 = izquierdo (A), 1 = derecho (X)

    private static long lastNanos = System.nanoTime();
    private static boolean attackHeld, useHeld, sprintApplied, sprintToggle, tabHeld;
    private static double scrollAcc;

    private ControllerHandler() {}

    // ------------------------------------------------------------------ bucle por frame

    @SubscribeEvent
    public static void onRenderTick(TickEvent.RenderTickEvent e) {
        if (e.phase != TickEvent.Phase.START) return;
        Minecraft mc = Minecraft.getInstance();

        long now = System.nanoTime();
        float dt = Math.min((now - lastNanos) / 1.0e9f, 0.1f);
        lastNanos = now;

        PAD.poll();
        notifyConnection(mc);

        for (Btn b : Btn.values()) {
            if (!PAD.held(b)) SUPPRESSED[b.ordinal()] = false;
        }

        if (!PAD.connected() || !mc.isWindowActive() || mc.getOverlay() != null) {
            releaseGameKeys(mc);
            return;
        }

        if (mc.screen != null) {
            handleScreen(mc, dt);
        } else if (mc.player != null && mc.level != null && mc.mouseHandler.isMouseGrabbed()) {
            handleGame(mc, dt);
        }
    }

    private static void notifyConnection(Minecraft mc) {
        if (PAD.justConnected) {
            PAD.justConnected = false;
            String key = PAD.mapped ? "mandouniversal.connected" : "mandouniversal.connected_generic";
            if (mc.gui != null) mc.gui.setOverlayMessage(Component.translatable(key, PAD.name), false);
        }
        if (PAD.justDisconnected) {
            PAD.justDisconnected = false;
            if (mc.gui != null) mc.gui.setOverlayMessage(Component.translatable("mandouniversal.disconnected"), false);
        }
    }

    // ------------------------------------------------------------------ en partida

    private static void handleGame(Minecraft mc, float dt) {
        Options o = mc.options;
        LocalPlayer p = mc.player;
        long win = mc.getWindow().getWindow();

        // Si empezamos un clic dentro de un menu y el menu se cerro, soltamos el boton del raton.
        for (int i = 0; i < CLICK_HELD.length; i++) {
            if (CLICK_HELD[i]) {
                fireButton(win, i, GLFW.GLFW_RELEASE);
                CLICK_HELD[i] = false;
            }
        }
        scrollAcc = 0;

        // Gatillos: RT = atacar/romper, LT = usar/colocar
        boolean rtNow = PAD.rt > MandoConfig.TRIGGER_THRESHOLD.get();
        if (rtNow != attackHeld) {
            attackHeld = rtNow;
            o.keyAttack.setDown(rtNow);
            if (rtNow) press(o.keyAttack);
        }
        boolean ltNow = PAD.lt > MandoConfig.TRIGGER_THRESHOLD.get();
        if (ltNow != useHeld) {
            useHeld = ltNow;
            o.keyUse.setDown(ltNow);
            if (ltNow) press(o.keyUse);
        }

        // Botones
        if (PAD.pressed(Btn.Y)) press(o.keyInventory);
        if (PAD.pressed(Btn.X)) press(o.keySwapOffhand);
        if (PAD.pressed(Btn.DPAD_UP)) press(o.keyTogglePerspective);
        if (PAD.pressed(Btn.DPAD_DOWN)) press(o.keyDrop);
        if (PAD.pressed(Btn.DPAD_LEFT)) press(o.keyAdvancements);
        if (PAD.pressed(Btn.DPAD_RIGHT)) press(o.keyPickItem);
        if (PAD.pressed(Btn.START)) mc.pauseGame(false);
        if (PAD.pressed(Btn.RB)) cycleHotbar(p, 1);
        if (PAD.pressed(Btn.LB)) cycleHotbar(p, -1);

        boolean tab = PAD.held(Btn.BACK);
        if (tab != tabHeld) {
            tabHeld = tab;
            o.keyPlayerList.setDown(tab);
        }

        // Correr: L3 alterna; se desactiva al soltar el stick
        float[] ls = stick(PAD.lx, PAD.ly);
        float mag = (float) Math.sqrt(ls[0] * ls[0] + ls[1] * ls[1]);
        if (PAD.pressed(Btn.L3)) sprintToggle = !sprintToggle;
        if (mag < 0.2f) sprintToggle = false;
        boolean wantSprint = sprintToggle || (MandoConfig.AUTO_SPRINT.get() && ls[1] < -0.9f);
        if (wantSprint != sprintApplied) {
            sprintApplied = wantSprint;
            o.keySprint.setDown(wantSprint);
        }

        // Camara con el stick derecho
        float[] rs = stick(PAD.rx, PAD.ry);
        if (rs[0] != 0f || rs[1] != 0f) {
            double sx = curve(rs[0]) * MandoConfig.LOOK_SPEED_X.get() * dt;
            double sy = curve(rs[1]) * MandoConfig.LOOK_SPEED_Y.get() * dt;
            if (MandoConfig.INVERT_Y.get()) sy = -sy;
            p.turn(sx, sy);
        }
    }

    /** Movimiento: stick izquierdo, A = saltar, B = agacharse (mantener). */
    @SubscribeEvent
    public static void onMovementInput(MovementInputUpdateEvent e) {
        if (!PAD.connected()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.screen != null || !mc.isWindowActive()) return;

        Input in = e.getInput();
        Player player = e.getEntity();

        float[] s = stick(PAD.lx, PAD.ly);
        if (s[0] != 0f || s[1] != 0f) {
            float forward = -s[1];
            float left = -s[0];
            float f = forward;
            float l = left;
            if (player.isCrouching()) {
                f *= 0.3f;
                l *= 0.3f;
            }
            in.forwardImpulse = f;
            in.leftImpulse = l;
            in.up = forward > 0.3f;
            in.down = forward < -0.3f;
            in.left = left > 0.3f;
            in.right = left < -0.3f;
        }
        if (gameHeld(Btn.A)) in.jumping = true;
        if (gameHeld(Btn.B)) in.shiftKeyDown = true;
    }

    // ------------------------------------------------------------------ en menus / inventarios

    private static void handleScreen(Minecraft mc, float dt) {
        releaseGameKeys(mc);
        Screen screen = mc.screen;
        long win = mc.getWindow().getWindow();

        for (Btn b : Btn.values()) {
            if (PAD.pressed(b)) SUPPRESSED[b.ordinal()] = true;
        }

        // Cursor con el stick izquierdo
        float[] l = stick(PAD.lx, PAD.ly);
        if (l[0] != 0f || l[1] != 0f) {
            double[] cx = new double[1];
            double[] cy = new double[1];
            GLFW.glfwGetCursorPos(win, cx, cy);
            double speed = MandoConfig.CURSOR_SPEED.get();
            double w = mc.getWindow().getScreenWidth();
            double h = mc.getWindow().getScreenHeight();
            double nx = Mth.clamp(cx[0] + curve(l[0]) * speed * dt, 0.0, w - 1.0);
            double ny = Mth.clamp(cy[0] + curve(l[1]) * speed * dt, 0.0, h - 1.0);
            GLFW.glfwSetCursorPos(win, nx, ny);
            fireCursor(win, nx, ny);
        }

        // A = clic izquierdo, X = clic derecho (se puede mantener para arrastrar)
        mouseButton(win, Btn.A, 0);
        mouseButton(win, Btn.X, 1);

        // Scroll: stick derecho y cruceta arriba/abajo
        float[] r = stick(PAD.rx, PAD.ry);
        boolean dpad = false;
        scrollAcc += -curve(r[1]) * 12.0 * dt;
        if (PAD.pressed(Btn.DPAD_UP)) { scrollAcc += 1; dpad = true; }
        if (PAD.pressed(Btn.DPAD_DOWN)) { scrollAcc -= 1; dpad = true; }
        if (r[1] == 0f && !dpad && Math.abs(scrollAcc) < 1.0) scrollAcc = 0;
        int notches = (int) scrollAcc;
        if (notches != 0) {
            scrollAcc -= notches;
            fireScroll(win, notches);
        }

        // Hotbar tambien dentro del inventario
        if (mc.player != null) {
            if (PAD.pressed(Btn.RB)) cycleHotbar(mc.player, 1);
            if (PAD.pressed(Btn.LB)) cycleHotbar(mc.player, -1);
        }

        // Acciones sobre el hueco bajo el cursor
        if (screen instanceof AbstractContainerScreen<?> cs
                && !(screen instanceof CreativeModeInventoryScreen)
                && mc.gameMode != null && mc.player != null) {
            Slot slot = cs.getSlotUnderMouse();
            if (slot != null) {
                int id = cs.getMenu().containerId;
                if (PAD.pressed(Btn.Y)) {
                    mc.gameMode.handleInventoryMouseClick(id, slot.index, 0, ClickType.QUICK_MOVE, mc.player);
                }
                if (PAD.pressed(Btn.R3)) {
                    mc.gameMode.handleInventoryMouseClick(id, slot.index, 0, ClickType.THROW, mc.player);
                }
                if (PAD.pressed(Btn.L3)) {
                    mc.gameMode.handleInventoryMouseClick(id, slot.index, 1, ClickType.THROW, mc.player);
                }
                if (PAD.pressed(Btn.DPAD_LEFT)) {
                    int hotbar = mc.player.getInventory().selected;
                    mc.gameMode.handleInventoryMouseClick(id, slot.index, hotbar, ClickType.SWAP, mc.player);
                }
            }
        }

        // B = cerrar / volver
        if (PAD.pressed(Btn.B) && mc.screen == screen && screen.shouldCloseOnEsc()) {
            screen.onClose();
        }
    }

    private static void mouseButton(long win, Btn b, int mouseButton) {
        if (PAD.pressed(b)) {
            fireButton(win, mouseButton, GLFW.GLFW_PRESS);
            CLICK_HELD[mouseButton] = true;
        } else if (PAD.released(b) && CLICK_HELD[mouseButton]) {
            fireButton(win, mouseButton, GLFW.GLFW_RELEASE);
            CLICK_HELD[mouseButton] = false;
        }
    }

    // ------------------------------------------------------------------ utilidades

    private static void releaseGameKeys(Minecraft mc) {
        Options o = mc.options;
        if (attackHeld) { o.keyAttack.setDown(false); attackHeld = false; }
        if (useHeld) { o.keyUse.setDown(false); useHeld = false; }
        if (sprintApplied) { o.keySprint.setDown(false); sprintApplied = false; }
        if (tabHeld) { o.keyPlayerList.setDown(false); tabHeld = false; }
        sprintToggle = false;
    }

    private static boolean gameHeld(Btn b) {
        return PAD.held(b) && !SUPPRESSED[b.ordinal()];
    }

    private static void press(KeyMapping km) {
        KeyMapping.click(km.getKey());
    }

    private static void cycleHotbar(LocalPlayer p, int dir) {
        if (p.isSpectator()) return;
        Inventory inv = p.getInventory();
        inv.selected = Math.floorMod(inv.selected + dir, 9);
    }

    /** Zona muerta radial con reescalado. */
    private static float[] stick(float x, float y) {
        float dz = MandoConfig.DEADZONE.get().floatValue();
        float m = (float) Math.sqrt(x * x + y * y);
        if (m <= dz) return new float[]{0f, 0f};
        float scale = Math.min(1f, (m - dz) / (1f - dz)) / m;
        return new float[]{x * scale, y * scale};
    }

    private static double curve(float v) {
        return Math.copySign(Math.pow(Math.abs(v), 1.5), v);
    }

    // Reinyectamos eventos de raton en los callbacks de GLFW que ya usa Minecraft,
    // asi los menus se comportan exactamente igual que con un raton real.

    private static void fireCursor(long win, double x, double y) {
        GLFWCursorPosCallback cb = GLFW.glfwSetCursorPosCallback(win, null);
        GLFW.glfwSetCursorPosCallback(win, cb);
        if (cb != null) cb.invoke(win, x, y);
    }

    private static void fireButton(long win, int button, int action) {
        GLFWMouseButtonCallback cb = GLFW.glfwSetMouseButtonCallback(win, null);
        GLFW.glfwSetMouseButtonCallback(win, cb);
        if (cb != null) cb.invoke(win, button, action, 0);
    }

    private static void fireScroll(long win, double yOffset) {
        GLFWScrollCallback cb = GLFW.glfwSetScrollCallback(win, null);
        GLFW.glfwSetScrollCallback(win, cb);
        if (cb != null) cb.invoke(win, 0.0, yOffset);
    }
}
